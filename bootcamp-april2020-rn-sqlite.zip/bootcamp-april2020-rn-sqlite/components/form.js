import React, { Component } from 'react'
import { View, Text } from 'react-native';



class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        return (
            <View>
                <Text>Form</Text>
            </View>
        );
    }
}

export default Form;