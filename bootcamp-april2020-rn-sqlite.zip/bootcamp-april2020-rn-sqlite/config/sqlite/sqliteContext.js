import React from 'react';

const SQLiteContext = React.createContext(null)
export default SQLiteContext