export const SIGN_IN_OK = "SIGN_IN_OK";
export const SIGN_OUT = "SIGN_OUT";
export const SIGN_UP = "SIGN_UP";
export const STORE_CONTACT = "STORE_CONTACT";