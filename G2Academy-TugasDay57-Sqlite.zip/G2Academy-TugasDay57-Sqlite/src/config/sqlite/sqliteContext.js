import React, { createContext } from 'react';

const SQLiteContext = createContext(null)
export default SQLiteContext