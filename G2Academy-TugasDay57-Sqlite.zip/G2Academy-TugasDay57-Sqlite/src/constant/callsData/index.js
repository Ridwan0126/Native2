export const CALLSDATA_USER1 = [
      {
        name:'Mark',
        image:'https://bootdey.com/img/Content/avatar/avatar1.png',
        date:'August 03',
        time:'11:20 AM',
        callType:'call',
        call:'call-missed'
      },
      {
        name:'Violet',
        image:'https://cdn.idntimes.com/content-images/community/2020/09/03-230c5b9bfca4d74be366cf90687e7e45_600x400.jpg',
        date:'Yesterday',
        time:'03:20 PM',
        callType:'call',
        call:'call-received'
      },
      {
        name:'Rose',
        image:'https://images.bisnis-cdn.com/thumb/posts/2021/03/23/1371168/rose-blackpink-100-hot.jpg?w=744&h=465',
        date:'Today',
        time:'08:00 AM',
        callType:'call',
        call:'call-missed'
      },
      {
        name:'Cattleya',
        image:'https://static.wikia.nocookie.net/violet-evergarden/images/9/9c/Cattleya_Baudelaire_%28Anime%29.png/revision/latest/top-crop/width/360/height/450?cb=20180112200807',
        date:'August 15',
        time:'05:50 PM',
        callType:'call',
        call:'call-missed'
      },
      {
        name:'Shayla',
        image:'https://images-na.ssl-images-amazon.com/images/I/81KgXSGE8BL.png',
        date:'August 16',
        time:'07:50 PM',
        callType:'video-call',
        call:'call-missed'
      },
      {
        name:'Joe',
        image:'https://bootdey.com/img/Content/avatar/avatar2.png',
        date:'August 11',
        time:'02:22 PM',
        callType:'call',
        call:'call-missed'
      },
      {
        name:'Steve',
        image:'https://bootdey.com/img/Content/avatar/avatar4.png',
        date:'July 15',
        time:'09:50 AM',
        callType:'call',
        call:'call-missed'
      },
      {
        name:'Bob',
        image:'https://bootdey.com/img/Content/avatar/avatar8.png',
        date:'July 14',
        time:'11:20 AM',
        callType:'call',
        call:'call-received'
      },
]

export const CALLSDATA_USER2 = [

  {
    name:'Curly',
    image:'https://bootdey.com/img/Content/avatar/avatar3.png',
    date:'July 22',
    time:'08:00 PM',
    callType:'video-call',
    call:'call-received'
  },
  {
    name:'Clark',
    image:'https://bootdey.com/img/Content/avatar/avatar6.png',
    date:'July 21',
    time:'11:12 AM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Fermond',
    image:'https://bootdey.com/img/Content/avatar/avatar7.png',
    date:'July 10',
    time:'09:50 AM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'July 5',
    time:'01:00 PM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'July 5',
    time:'01:00 PM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'July 5',
    time:'01:00 PM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'July 5',
    time:'01:00 PM',
    callType:'call',
    call:'call-missed'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'July 5',
    time:'13:00',
    callType:'call',
    call:'call-missed'
  },
]