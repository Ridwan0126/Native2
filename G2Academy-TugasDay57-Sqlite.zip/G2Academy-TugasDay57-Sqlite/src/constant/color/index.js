export const COLOR = {
    main:"#00716F",
    darkmain:"#04555c",
    secondary:'#e1e8e9',
    gray:'#CBCBCB',
    orange:'#f5a623',
    red:'red'
}
//00716F