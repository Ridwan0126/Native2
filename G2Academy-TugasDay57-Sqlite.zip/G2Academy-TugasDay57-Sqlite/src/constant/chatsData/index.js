export const CHATSDATA_USER1 = [
    {
        name:'Mark',
        image:'https://bootdey.com/img/Content/avatar/avatar1.png',
        time:'08:00 AM',
        message:'Hello there?',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Violet',
        image:'https://cdn.idntimes.com/content-images/community/2020/09/03-230c5b9bfca4d74be366cf90687e7e45_600x400.jpg',
        time:'05:30 AM',
        message:'Can I Ask?',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Rose',
        image:'https://images.bisnis-cdn.com/thumb/posts/2021/03/23/1371168/rose-blackpink-100-hot.jpg?w=744&h=465',
        time:'04:45 PM',
        message:'Hi Fian, Can We Talk Now?',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Cattleya',
        image:'https://static.wikia.nocookie.net/violet-evergarden/images/9/9c/Cattleya_Baudelaire_%28Anime%29.png/revision/latest/top-crop/width/360/height/450?cb=20180112200807',
        time:'11:30 AM',
        message:'Are U Busy?',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Shayla',
        image:'https://images-na.ssl-images-amazon.com/images/I/81KgXSGE8BL.png',
        time:'09:00 AM',
        message:'Hi Hi!',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Joe',
        image:'https://bootdey.com/img/Content/avatar/avatar2.png',
        time:'07:15 AM',
        message:'Photo',
        icon:'image',
        messageType:'Photo'
      },
      {
        name:'Steve',
        image:'https://bootdey.com/img/Content/avatar/avatar4.png',
        time:'00:11 PM',
        message:'Hey',
        icon:'image',
        messageType:'text'
      },
      {
        name:'Bob',
        image:'https://bootdey.com/img/Content/avatar/avatar8.png',
        time:'00:50 PM',
        message:'Hello',
        icon:'image',
        messageType:'text'
      },
]

export const CHATSDATA_USER2 = [
  {
    name:'Curly',
    image:'https://bootdey.com/img/Content/avatar/avatar3.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Clark',
    image:'https://bootdey.com/img/Content/avatar/avatar6.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Fermond',
    image:'https://bootdey.com/img/Content/avatar/avatar7.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    time:'00:11 PM',
    message:'Hey',
    icon:'image',
    messageType:'text'
  },
]