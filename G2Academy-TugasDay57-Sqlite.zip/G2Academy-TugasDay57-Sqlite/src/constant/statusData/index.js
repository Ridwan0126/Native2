export const STATUSDATA_USER1 = [
      {
        name:'Mark',
        image:'https://bootdey.com/img/Content/avatar/avatar1.png',
        date:'',
        time:'15 minutes ago',
        active:2
      },
      {
        name:'Violet',
        image:'https://cdn.idntimes.com/content-images/community/2020/09/03-230c5b9bfca4d74be366cf90687e7e45_600x400.jpg',
        date:'',
        time:'23 minutes ago',
        active:4
      },
      {
        name:'Rose',
        image:'https://images.bisnis-cdn.com/thumb/posts/2021/03/23/1371168/rose-blackpink-100-hot.jpg?w=744&h=465',
        date:'Today',
        time:'10:30 AM',
      },
      {
        name:'Cattleya',
        image:'https://static.wikia.nocookie.net/violet-evergarden/images/9/9c/Cattleya_Baudelaire_%28Anime%29.png/revision/latest/top-crop/width/360/height/450?cb=20180112200807',
        date:'Today',
        time:'04:10 PM',
      },
]

export const STATUSDATA_USER2 = [
  {
    name:'Curly',
    image:'https://bootdey.com/img/Content/avatar/avatar3.png',
    date:'',
    time:'30 minutes ago',
  },
  {
    name:'Clark',
    image:'https://bootdey.com/img/Content/avatar/avatar6.png',
    date:'',
    time:'45 minutes ago',
  },
  {
    name:'Fermond',
    image:'https://bootdey.com/img/Content/avatar/avatar7.png',
    date:'Today',
    time:'15:00 PM',
  },
  {
    name:'Steve',
    image:'https://bootdey.com/img/Content/avatar/avatar4.png',
    date:'Today',
    time:'16:55 PM',
  },
]